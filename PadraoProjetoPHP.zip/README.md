# PadraoProjetoPHP
Deve-se instalar o composer no php do projeto
Criamos o composer.json com um require em branco
Depois baixamos o composer.phar do site https://packagist.org/

# Componentes abaixo servem para autoload.php
Rodamos o comando php composer.phar install
Rodamos o comando composer require twig/twig


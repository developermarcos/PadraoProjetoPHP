<?php
class ErroController{
    public function index(){
        echo"Erro Controller";
    }
}
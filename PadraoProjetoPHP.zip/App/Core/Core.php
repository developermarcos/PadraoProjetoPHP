<?php
    class Core{
        public function start($URL){
            $acao = 'index';
            if(!empty($URL['pagina'])){
                $controller = ucfirst($URL['pagina'].'Controller');
            }else{
                $controller = 'ErroController';
            }
            
            if(!class_exists($controller)){
                $controller = 'ErroController';
            }
            call_user_func_array(array(new $controller, $acao), array());
            
        }
    }